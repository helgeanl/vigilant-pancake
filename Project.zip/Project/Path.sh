export GOPATH=$HOME/vigilant-pancake/Project
export PATH=$PATH:$GOPATH/bin